package com.example.translatebox

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()
    private var latest: Image? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null

    private lateinit var box: View
    private lateinit var btn: TextView
    private lateinit var panel: TextView
    private lateinit var boxLp: WindowManager.LayoutParams
    private lateinit var btnLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private var panelShown = false
    private var overlayBuilt = false
    private var sw = 0
    private var sh = 0

    private val recognizers by lazy {
        listOf(
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
            TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    @Suppress("DEPRECATION")
    private fun readData(intent: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("tb", "Translate Box", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, "tb")
            .setContentTitle("Translate Box شغّال")
            .setContentText("اضغط هنا للإيقاف")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = readData(intent)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, handler)
        projection = p

        setupCapture(p)
        buildOverlay()
        return START_NOT_STICKY
    }

    // ---------- التقاط الشاشة ----------
    private fun setupCapture(p: MediaProjection) {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels
        sh = dm.heightPixels
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val im = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            synchronized(lock) {
                latest?.close()
                latest = im
            }
        }, handler)
        reader = r
        vd = p.createVirtualDisplay(
            "tb", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    private fun grab(): Bitmap? {
        val full: Bitmap
        synchronized(lock) {
            val im = latest ?: return null
            val pl = im.planes[0]
            val w = pl.rowStride / pl.pixelStride
            full = Bitmap.createBitmap(w, im.height, Bitmap.Config.ARGB_8888)
            pl.buffer.rewind()
            full.copyPixelsFromBuffer(pl.buffer)
        }
        val loc = IntArray(2)
        box.getLocationOnScreen(loc)
        val inset = dp(6)
        val x = (loc[0] + inset).coerceIn(0, sw - 1)
        val y = (loc[1] + inset).coerceIn(0, sh - 1)
        val wd = (box.width - 2 * inset).coerceAtMost(sw - x)
        val ht = (box.height - 2 * inset).coerceAtMost(sh - y)
        if (wd <= 10 || ht <= 10) return null
        return Bitmap.createBitmap(full, x, y, wd, ht)
    }

    // ---------- الواجهة العائمة ----------
    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun buildOverlay() {
        // المربع الأصفر
        box = object : View(this) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            override fun onDraw(c: Canvas) {
                paint.color = 0xFFFFC107.toInt()
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(3).toFloat()
                c.drawRoundRect(
                    RectF(dp(2).toFloat(), dp(2).toFloat(), width - dp(2).toFloat(), height - dp(2).toFloat()),
                    dp(12).toFloat(), dp(12).toFloat(), paint
                )
                paint.style = Paint.Style.FILL
                c.drawCircle(width - dp(22).toFloat(), height - dp(22).toFloat(), dp(12).toFloat(), paint)
            }
        }
        boxLp = overlayParams(dp(260), dp(120)).apply { x = dp(40); y = dp(300) }

        var lx = 0f
        var ly = 0f
        var resizing = false
        box.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lx = e.rawX; ly = e.rawY
                    resizing = e.x > v.width - dp(56) && e.y > v.height - dp(56)
                    hidePanel()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - lx).toInt()
                    val dy = (e.rawY - ly).toInt()
                    lx = e.rawX; ly = e.rawY
                    if (resizing) {
                        boxLp.width = max(dp(80), boxLp.width + dx)
                        boxLp.height = max(dp(60), boxLp.height + dy)
                    } else {
                        boxLp.x += dx
                        boxLp.y += dy
                    }
                    wm.updateViewLayout(box, boxLp)
                }
            }
            true
        }

        // زر الترجمة
        btn = TextView(this).apply {
            text = "ترجمة"
            setTextColor(Color.BLACK)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                setColor(0xFFFFC107.toInt())
                cornerRadius = dp(24).toFloat()
            }
        }
        btnLp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { x = dp(40); y = dp(200) }

        var bx = 0f
        var by = 0f
        var moved = 0f
        btn.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { bx = e.rawX; by = e.rawY; moved = 0f }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - bx).toInt()
                    val dy = (e.rawY - by).toInt()
                    bx = e.rawX; by = e.rawY
                    moved += abs(dx) + abs(dy)
                    btnLp.x += dx
                    btnLp.y += dy
                    wm.updateViewLayout(btn, btnLp)
                }
                MotionEvent.ACTION_UP -> if (moved < dp(8)) translateNow()
            }
            true
        }

        // لوحة النتيجة
        panel = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(16), dp(12), dp(16), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            background = GradientDrawable().apply {
                setColor(0xEE222222.toInt())
                cornerRadius = dp(16).toFloat()
            }
            setOnClickListener { hidePanel() }
        }
        panelLp = overlayParams(sw - dp(32), WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { x = dp(16) }

        wm.addView(box, boxLp)
        wm.addView(btn, btnLp)
        overlayBuilt = true
    }

    private fun showPanel(text: String) {
        panel.text = text
        val below = boxLp.y + boxLp.height + dp(8)
        panelLp.y = if (below + dp(200) < sh) below else max(dp(40), boxLp.y - dp(200))
        if (panelShown) {
            wm.updateViewLayout(panel, panelLp)
        } else {
            wm.addView(panel, panelLp)
            panelShown = true
        }
    }

    private fun hidePanel() {
        if (panelShown) {
            safeRemove(panel)
            panelShown = false
        }
    }

    private fun safeRemove(v: View) {
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    // ---------- القراءة والترجمة ----------
    private fun translateNow() {
        hidePanel()
        handler.postDelayed({
            val bmp = grab()
            if (bmp == null) {
                showPanel("ما قدرت أصوّر الشاشة، جرّب مرة ثانية")
                return@postDelayed
            }
            showPanel("جاري القراءة...")
            ocr(bmp) { text ->
                if (text.isBlank()) showPanel("ما لقيت نص داخل المربع")
                else translate(text)
            }
        }, 300)
    }

    private fun ocr(bmp: Bitmap, done: (String) -> Unit) {
        val img = InputImage.fromBitmap(bmp, 0)
        var best = ""
        var left = recognizers.size
        for (r in recognizers) {
            r.process(img)
                .addOnSuccessListener { if (it.text.length > best.length) best = it.text }
                .addOnCompleteListener { if (--left == 0) done(best.trim()) }
        }
    }

    private fun translate(text: String) {
        LanguageIdentification.getClient().identifyLanguage(text)
            .addOnSuccessListener { code ->
                val src = if (code == "und") null else TranslateLanguage.fromLanguageTag(code)
                if (src == null) {
                    showPanel("ما قدرت أحدد لغة النص:\n$text")
                    return@addOnSuccessListener
                }
                if (src == TranslateLanguage.ARABIC) {
                    showPanel(text)
                    return@addOnSuccessListener
                }
                showPanel("جاري الترجمة... (أول مرة يحمّل اللغة، يحتاج إنترنت)")
                val tr = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(src)
                        .setTargetLanguage(TranslateLanguage.ARABIC)
                        .build()
                )
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener {
                        tr.translate(text)
                            .addOnSuccessListener { out -> showPanel(out) }
                            .addOnFailureListener { e -> showPanel("خطأ في الترجمة: ${e.message}") }
                            .addOnCompleteListener { tr.close() }
                    }
                    .addOnFailureListener { e ->
                        showPanel("فشل تحميل اللغة (تأكد من الإنترنت): ${e.message}")
                        tr.close()
                    }
            }
            .addOnFailureListener { e -> showPanel("خطأ: ${e.message}") }
    }

    override fun onDestroy() {
        hidePanel()
        if (overlayBuilt) {
            safeRemove(box)
            safeRemove(btn)
        }
        synchronized(lock) { latest?.close(); latest = null }
        vd?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
